# Detailed Analysis: Intersection Experiment

## Summary of What The Experiment Did

**Setup:**
1. Trained 50 models on `binary_classification_synthetic` (signal - real patterns)
2. Trained 50 models on `binary_random_labels` (noise - random labels)
3. Computed PCA dimension for each dataset separately
4. Computed PCA dimension for all 100 models combined
5. Calculated principal angles between the two subspaces

**Results Reported:**
- Signal dimension: 41.4D
- Noise dimension: 41.8D
- Combined dimension: 59.7D
- Principal angles: 55-90° (nearly orthogonal)
- Conclusion: "NO INTERSECTION"

---

## Step-by-Step Analysis

### Step 1: The Math Check

**If tasks were PERFECTLY ALIGNED (same subspace):**
- Signal: 41.4D, Noise: 41.8D
- Combined should be: ~42D (max of the two)
- Actual: 59.7D
- **Doesn't match** ✗

**If tasks were COMPLETELY ORTHOGONAL (no overlap):**
- Signal: 41.4D, Noise: 41.8D
- Combined should be: ~83D (sum of the two)
- Actual: 59.7D
- **Doesn't match** ✗

**Actual situation: PARTIAL OVERLAP**
- Combined (59.7D) is between max (42D) and sum (83D)
- **Matches!** ✓
- This suggests ~23D of overlap, ~19D signal-specific, ~19D noise-specific

### Step 2: The Sample Size Problem

**Critical issue:**
- 50 models per task
- Each task has ~42D
- **Samples per dimension: 1.2**
- **Need: ~10 samples per dimension**
- **Status: SEVERELY UNDERSAMPLED** ⚠

**What this means:**
- The 42D estimate is unreliable
- Could be much higher or lower
- Principal angles are unreliable too

### Step 3: Consistency Check with Previous Results

**100-model experiment (same task):**
- 100 models → 71.9D effective dimension
- Scaling: dimension ≈ 0.72 × sample_size

**Current experiment (50 models per task):**
- 50 models → 41.4D (signal)
- 50 models → 41.8D (noise)
- Expected: 50 × 0.72 = 36D
- Actual: 41.4D and 41.8D
- **Close enough!** ✓

**This means:**
- The dimension is still growing linearly with sample size
- We haven't saturated
- The 42D is just because we only used 50 samples

### Step 4: What If We Had More Samples?

**Extrapolating to 100 models per task:**
- Signal: 100 models → ~72D (from scaling law)
- Noise: 100 models → ~72D (from scaling law)

**Then for intersection:**
- If perfectly aligned: combined = 72D
- If orthogonal: combined = 144D
- If partial (like now): combined = ~100-120D?

**We can't know until we actually run it with 100+ samples!**

### Step 5: The Principal Angles Issue

**Reported:**
- Min angle: 55.6°
- Mean angle: 74.4°
- These are large (nearly orthogonal)

**BUT:**
- This is comparing 44D subspace to 45D subspace
- Each based on only 50 samples
- These subspaces themselves are unreliable!

**Analogy:**
- It's like measuring the angle between two lines
- But each line is drawn through only 1-2 noisy points
- The angle you measure is mostly noise!

---

## The Real Problem: Dimension Growth

### The Fundamental Issue

**From all our experiments:**
```
Sample size | Dimension
------------|----------
10          | 8.6D
20          | 17.8D
50          | 41.4D
100         | 71.9D
```

**This is LINEAR GROWTH:**
- Dimension ≈ 0.72 × sample_size
- It doesn't saturate!

**What this means for intersection:**
- We measured 42D for signal (50 samples)
- We measured 42D for noise (50 samples)
- But these would be 72D each with 100 samples
- And maybe 144D each with 200 samples!

**The intersection analysis is meaningless** if the individual manifolds aren't well-characterized!

---

## What We Actually Learned

### Finding 1: Dimension Scales with Sample Size

**Confirmed again:**
- 50 samples → ~42D
- 100 samples → ~72D
- This holds for both signal AND noise

**Implication:**
- We still don't know the true manifold dimension
- Could be 100D, 200D, or keep growing

### Finding 2: Signal and Noise Behave Similarly

**Both datasets:**
- Similar dimension (~42D for 50 samples)
- Similar scaling behavior
- This confirms: **optimization dynamics dominate task semantics**

**But we already knew this from the earlier "clustering" experiment!**

### Finding 3: The Orthogonality Claim is Questionable

**Math shows:**
- If truly orthogonal: combined = 83D
- Actually: combined = 60D
- Difference: 23D of overlap

**This suggests ~28% overlap** (23D out of 83D total)

**NOT "no intersection"!**

---

## Critical Flaws in the Experiment

### Flaw 1: Undersampling

- 50 samples for ~42D manifold
- Need 10× more (500 samples) for reliable estimation
- **Consequence:** Unreliable dimension estimates

### Flaw 2: Dimension Growth Not Addressed

- Dimension grows with sample size
- Haven't found true dimension yet
- **Consequence:** Comparing apples to oranges

### Flaw 3: Misinterpretation of Results

- Combined = 60D, not 83D → suggests overlap
- But reported as "no intersection"
- **Consequence:** Wrong conclusion!

### Flaw 4: Principal Angles on Unreliable Subspaces

- Each subspace based on 50 samples
- Angles between poorly-defined subspaces
- **Consequence:** Angle measurements are noise

---

## What We Should Do

### Option 1: Re-run with More Samples

**Use the existing 100-model data!**
- We already have 100 models trained on signal (from before)
- Train 100 NEW models on noise
- Then properly compare with adequate sampling

### Option 2: Wait for Saturation Test

The 300-model saturation test is still running. Once it completes:
- We'll know if/when dimension saturates
- Only then can we meaningfully compute intersection

### Option 3: Use a Different Method

Instead of PCA dimension, use:
- **Direct subspace overlap:** Project signal models onto noise subspace
- **Distance-based:** Are signal/noise models closer to each other than random?
- **Classification:** Can we distinguish signal from noise models?

---

## Corrected Interpretation

### What the Results Actually Show

**Combined dimension (60D) < Sum of individuals (83D)**
→ There IS some overlap (~23D)

**But:**
- Overlap might just be the "growing with sample size" artifact
- Can't trust specific numbers due to undersampling
- Need more data to know for sure

### Conservative Conclusion

**We cannot determine if intersection exists** because:
1. Individual manifold dimensions are still growing
2. Only 50 samples per task (10× too few)
3. True dimensions unknown

**We need:**
- Saturated dimension estimates first
- Then 100+ samples per task
- Then intersection analysis will be meaningful

---

## Recommendation

**WAIT for the 300-model saturation test to complete.**

Once we know:
- Does dimension saturate? (at what value?)
- Then we can design proper intersection test
- With appropriate sample sizes

**Don't trust the "no intersection" claim from this experiment!**

---

## Bottom Line

**The experiment was premature.**

We tried to measure intersection before knowing:
1. What the individual manifold dimensions are
2. Whether they're saturated or still growing

**It's like:**
- Trying to find where two roads intersect
- But the roads are still being built
- And we can only see 10% of each road

**Result:** Unreliable and possibly wrong!
