# Basin Structure Analysis

## Critical Findings

### 1. The 100 Models Are in a SINGLE Basin ✓

Evidence is overwhelming:
- **Distance CV: 4.3%** (extremely tight cluster)
- **Silhouette score: 0.011** (no meaningful sub-clustering)
- **Separation ratio: 0.21** (internal variations are tiny)
- **DBSCAN: 1 cluster** at all reasonable epsilon values

**Conclusion:** All 100 models converged to the **SAME 72-dimensional basin**.

The 72D is the **true dimension of THIS basin**, not an artifact of averaging.

---

## 2. Are There Other Basins?

### Evidence for Multiple Basins

From our **distant initialization experiment**:
- Models initialized 40-80+ units away **DID NOT** return to this basin
- They converged to **different manifolds**
- Separation ratio: **8.24×** (between basins) vs **0.21** (within basin)
- **This is 40× larger separation!**

**Conclusion:** Multiple basins **definitely exist**.

### The Key Question: How Many Basins?

We know:
1. **At least 2 basins** (normal init basin + distant init basin)
2. Basin boundaries are at **~40 units** from basin center
3. Weight space is **465-dimensional**

#### Geometric Calculation

If basins have:
- **Effective radius:** ~40 units (from attraction test)
- **Dimension:** 72D each
- **Ambient space:** 465D

Simple volume argument:
- Volume of 465D sphere scales as r^465
- Volume of 72D basin scales as r^72
- **The ambient space is VASTLY larger** than any single basin

**Implication:** There is room for **many basins** (potentially thousands or more).

#### Are There Infinitely Many?

This depends on the **continuous vs discrete** nature of the loss landscape:

**Arguments for FINITE number:**
- Network has finite parameters (465)
- Discrete optimization (SGD with finite steps)
- Initialization distribution is bounded
- Realistic training always samples finite region

**Arguments for INFINITE (or very large):**
- Weight space is continuous (R^465)
- Different initializations → different basins
- No obvious symmetry that would merge basins
- 465D space has exponentially many "rooms"

**Most likely:** **Very large finite number** (thousands to millions) rather than literally infinite.

---

## 3. What is the "Intersection"?

This is the critical conceptual question. There are two interpretations:

### Interpretation A: Intersection = Common Basin

**Question:** Do all models from **default random initialization** end up in the same basin?

**Answer:** **YES** (our 100 models show this)

**The "intersection" is:**
- The **72D basin** that normal init finds
- All 100 models converged here
- This basin is well-defined and bounded

### Interpretation B: Intersection = Universal Across ALL Basins

**Question:** Is there a **common subspace** shared by ALL basins?

**Answer:** **UNKNOWN** (we haven't checked this!)

**To test this, we need to:**
1. Find multiple different basins (distant inits)
2. Extract their individual dimensions
3. Check if they **overlap** or are completely **disjoint**

---

## 4. Critical Experiment Needed: Basin Discovery

To answer "how many basins?" and "do they intersect?", we need:

### Experiment Design

1. **Systematic initialization sweep:**
   - Initialize at distances: 0, 10, 20, 30, 40, 50, 60, 80, 100, 120
   - Multiple random directions at each distance
   - 10 replicates per (distance, direction) pair
   - Total: ~100-200 models across different init regions

2. **Convergence tracking:**
   - Track final weights
   - Measure which basin each model reached
   - Cluster the final convergence points

3. **Basin identification:**
   - Use DBSCAN or hierarchical clustering on final weights
   - Identify distinct basins (silhouette score > 0.5)
   - Count total number of basins found

4. **Intersection analysis:**
   - For each basin, compute PCA
   - Check if PC directions are **aligned** across basins
   - Measure **subspace overlap** between basins

### Expected Outcomes

**Scenario 1: Independent Basins (No Intersection)**
- Each basin is 72D
- Basin subspaces are **orthogonal** or nearly so
- No common lower-dimensional structure
- Each basin represents different "attractor"

**Scenario 2: Shared Subspace (True Intersection)**
- All basins lie in a **common lower-dimensional subspace** (e.g., 10D)
- Within this 10D space, basins are separated
- This would vindicate the "universal subspace" hypothesis!
- The 72D would be an artifact of looking at one basin

**Scenario 3: Partial Overlap**
- Basins share some dimensions but not all
- E.g., 20D common + 52D basin-specific
- Suggests task-independent and task-specific components

---

## 5. Current Understanding Summary

### What We Know ✓

1. **Single basin from normal init:**
   - All 100 models in same 72D basin
   - Very tight clustering (CV = 4.3%)
   - Well-defined boundary (~40 units radius)

2. **Multiple basins exist:**
   - Distant init (40+ units) → different basin
   - Separation ratio: 8.24× (between) vs 0.21× (within)
   - At least 2 basins confirmed

3. **Each basin is high-dimensional:**
   - NOT low-D manifolds (not 8D!)
   - ~72D per basin (for [16,16] architecture)
   - Modest compression from 465D (6.5×)

4. **Dynamics dominate semantics:**
   - Signal and noise models → same basin
   - Task doesn't matter for basin selection
   - Init distance matters more than task

### What We Don't Know ?

1. **Total number of basins:**
   - At least 2, likely many more
   - Could be hundreds, thousands, or "effectively infinite"

2. **Basin structure in weight space:**
   - Are they arranged in a pattern?
   - Is there a "meta-structure" organizing them?
   - Do they tile the space or cluster together?

3. **Intersection across basins:**
   - Do all basins share a common subspace?
   - Or are they completely disjoint?
   - This is the KEY question for universality!

4. **Basin dimension variation:**
   - Are all basins 72D?
   - Or do different basins have different dimensions?
   - Does it depend on init distance?

---

## 6. Recommended Next Experiments

### Priority 1: Basin Discovery & Intersection Test

**Goal:** Find multiple basins and check for shared subspace

**Method:**
```bash
python run_basin_discovery.py \
  --n-distances 10 \
  --n-directions 5 \
  --n-replicates 3 \
  --min-distance 0 \
  --max-distance 120
```

This would give us ~150 models across different initialization regions.

**Analysis:**
- Cluster final weights (identify basins)
- PCA on each basin separately
- Compute subspace overlap between basin PCAs
- Check if there's a common lower-D intersection

### Priority 2: Architecture Sweep

**Goal:** Check if 72D scales with architecture

**Method:**
```bash
for arch in "[8,8]" "[16,16]" "[32,32]" "[16,16,16]"; do
  python run_large_scale_sampling.py --hidden-dims $arch
done
```

**Expected:** Dimension might scale with total parameters or depth.

### Priority 3: Task Family Comparison

**Goal:** Do different task types have different basins?

**Method:**
- Train 100 models on regression task
- Train 100 models on multi-class task
- Compare to our 100 binary classification models
- Check if they cluster in same or different regions

---

## 7. Theoretical Implications

### If Basins are Disjoint (No Intersection)

**Implications:**
- No "universal subspace" across all models
- Initialization is critical (determines which basin)
- Each basin might represent different functional regime
- Transfer learning only works within-basin

**Explains:**
- Why some inits fail (wrong basin)
- Why transfer sometimes fails (different basins)
- Importance of good initialization schemes

### If Basins Share Subspace (Intersection Exists)

**Implications:**
- True "universal subspace" of dimension < 72D
- All training converges to variations within this subspace
- Transfer should work universally (same subspace)
- Architecture strongly constrains solutions

**Explains:**
- Why transfer learning often works
- Why certain directions in weight space are "unused"
- Potential for dimensionality reduction in models

---

## 8. Answer to Your Question

> "ok so this is actually in the intersection? have we found all basins or are there infinitely many and in the intersection?"

**Short Answer:**

1. **In the intersection?**
   - The 100 models are in the **intersection of the single basin** they all reached
   - We don't know if this basin intersects with OTHER basins in a lower-D subspace
   - That requires comparing multiple basins (experiment needed)

2. **Found all basins?**
   - **NO** - we've only found 1 basin thoroughly (from normal init)
   - We know at least 1 other basin exists (from distant init)
   - Likely many more basins exist (perhaps thousands)

3. **Infinitely many?**
   - Probably not literally infinite
   - But potentially **very large number** (thousands+)
   - Depends on volume of 465D space vs basin size

4. **In the intersection?** (rephrased)
   - **Unknown** whether different basins share a common subspace
   - This is the **critical next question**
   - Requires basin discovery + subspace overlap analysis

**The 72D we found is:**
- ✓ Real (not undersampling artifact)
- ✓ Single basin (all 100 models together)
- ✓ Highly reproducible (tight clustering)
- ? Unknown if it's part of a universal intersection across basins

---

## Next Step

Should we run the **basin discovery experiment** to find multiple basins and test for intersection?

This would definitively answer whether there's a universal subspace or if basins are independent.
