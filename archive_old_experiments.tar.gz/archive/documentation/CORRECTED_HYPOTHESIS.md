# The CORRECT Universal Subspace Hypothesis

## What We Were Testing (WRONG):

**Single-task manifold dimension:**
- Train 100 models on Dataset A
- Measure dimension of their convergence region
- Found: ~72D

**This tells us:** How constrained is optimization for ONE specific task.

**This does NOT tell us:** Whether different tasks share a common subspace!

---

## What We SHOULD Test (CORRECT):

**Multi-task intersection:**
1. Train 50 models on **Dataset A** → Manifold_A (~72D?)
2. Train 50 models on **Dataset B** → Manifold_B (~72D?)
3. Train 50 models on **Dataset C** → Manifold_C (~72D?)
4. Find **INTERSECTION** of Manifold_A ∩ Manifold_B ∩ Manifold_C

**Critical question:** What is dim(Intersection)?

---

## The Three Scenarios:

### Scenario 1: Universal Low-D Subspace (Original Hypothesis)

```
Dataset A models → 72D manifold
Dataset B models → 72D manifold
Dataset C models → 72D manifold

All three manifolds ALIGNED in same 10D subspace!

Intersection = 10D ← THE UNIVERSAL SUBSPACE
```

**This would mean:**
- All tasks converge to a common 10D subspace
- The 72D is "how they move within" that 10D space
- Strong universality!

### Scenario 2: Partial Overlap

```
Dataset A → 72D (uses dimensions 1-72)
Dataset B → 72D (uses dimensions 10-82)
Dataset C → 72D (uses dimensions 20-92)

Intersection = 30D (overlap of all three)
```

**This would mean:**
- Tasks share SOME dimensions but not all
- Partial universality
- ~30D is task-independent, ~42D is task-specific

### Scenario 3: Disjoint Manifolds (No Universality)

```
Dataset A → 72D (orthogonal subspace)
Dataset B → 72D (different orthogonal subspace)
Dataset C → 72D (yet another subspace)

Intersection = 0D (or very small)
```

**This would mean:**
- Each task uses completely different parts of weight space
- No universal subspace
- Hypothesis is FALSE

---

## How to Measure Intersection:

### Method 1: Principal Angles

For each pair of datasets:
1. Compute PCA subspace for Dataset A models
2. Compute PCA subspace for Dataset B models
3. Calculate **principal angles** between subspaces

**Principal angles:**
- Small angles (< 10°) → aligned dimensions (SHARED)
- Large angles (> 80°) → orthogonal dimensions (INDEPENDENT)

**Count aligned dimensions → intersection size**

### Method 2: Global PCA

1. Combine all models from all datasets
2. Run PCA on combined set
3. Check global dimension vs individual dimensions

**If:**
- Global_dim < Individual_dim → Intersection exists!
- Global_dim = Individual_dim → Some overlap
- Global_dim > Individual_dim → Disjoint (adding dimensions)

Example:
- Dataset A: 72D
- Dataset B: 72D
- Combined: 60D ← They share a 60D intersection!

Or:
- Dataset A: 72D
- Dataset B: 72D
- Combined: 144D ← Completely disjoint!

---

## Why This Matters:

### If Intersection is 10-20D:
- **Strong universal subspace**
- Can compress all models dramatically
- Transfer learning works universally
- Train on any task → useful for all tasks

### If Intersection is 40-60D:
- **Weak universal subspace**
- Modest compression possible
- Transfer works within task families
- Some dimensions are task-specific

### If Intersection is ~0D:
- **No universal subspace**
- Each task is independent
- No general compression
- Transfer only works for similar tasks

---

## The Experiment Running Now:

**test_universal_intersection.py** is training:
- 50 models on `binary_classification_synthetic` (signal)
- 50 models on `binary_random_labels` (noise)

Then computing:
1. Principal angles between their subspaces
2. Global PCA dimension
3. Intersection estimate

**This will tell us if signal and noise share a subspace!**

---

## Expected Results:

### Prediction 1: They Share Subspace

From our earlier finding: signal and noise models **cluster together**.

This suggests:
- Intersection dimension ≈ 60-70D
- Optimization dynamics dominate
- Task (signal vs noise) doesn't matter
- **They use the SAME subspace**

### Prediction 2: Minimal Intersection

Alternative interpretation:
- Signal models: 72D subspace
- Noise models: 72D (different) subspace
- Intersection: ~5-10D
- Most dimensions are task-specific

### Which is Right?

The principal angles will tell us!

If angles are **small** (< 20°) → Shared subspace (Prediction 1)
If angles are **large** (> 60°) → Separate subspaces (Prediction 2)

---

## The Real Question:

You asked: **"Does the intersection have infinitely many components?"**

The corrected version is:

**"What is the dimension of the intersection of manifolds across all tasks?"**

Possible answers:
- **0D:** No intersection (tasks are disjoint)
- **10-20D:** Strong universal subspace
- **50-80D:** Weak universal subspace
- **~465D:** No compression (fills the space)

We'll know in ~30 minutes when the experiment completes!

---

## Why We Got Confused:

**Single-task experiment:**
- Trains many models on SAME task
- Measures "how tight is the convergence?"
- Found: 72D (but grows with sample size!)

**Multi-task experiment (CORRECT):**
- Trains models on DIFFERENT tasks
- Measures "do tasks share a common subspace?"
- Will find: Intersection dimension

**The 72D tells us about one task.**
**The intersection tells us about universality!**

---

## Next Steps After This:

Once we know the intersection for 2 tasks (signal vs noise), we should:

1. Add more tasks (regression, multi-class, etc.)
2. Check if intersection dimension DECREASES with more tasks
3. Find the "ultimate" intersection across ALL tasks

**If intersection stays > 10D after many tasks → Universal subspace exists!**

---

## Files:

- **test_universal_intersection.py** - The correct experiment (running now)
- **results_intersection/** - Will contain the answer!

Check back in 30-45 minutes for results!
