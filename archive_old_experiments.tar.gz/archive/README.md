# Archive: Low-Sample Experiments

This folder contains experiments with **insufficient sampling** that led to unreliable results.

## Problems Identified:

### 1. Dimension Growth with Sample Size
- 10 models → 9D
- 50 models → 42D
- 100 models → 72D
- **Dimension ≈ 0.72 × sample_size** (not saturated!)

### 2. Undersampling Issues
All experiments here used too few samples:
- `results_quick_basin/` - Only 15 models total
- `results_intersection/` - Only 50 models per task (need 500+)
- `results_dynamics/` - Only 10 models (claimed 8D - wrong!)

### 3. Wrong Conclusions
- Initially claimed 8D manifold (actually undersampling artifact)
- Claimed "no intersection" (actually undersampled, ~28% overlap seen)
- Claimed "multiple basins" (actually measurement noise)

## Lessons Learned:

1. **Need 10+ samples per dimension** for reliable estimation
2. **Always check saturation** - does dimension stop growing?
3. **Compare to random baseline** - are we better than noise?
4. **Verify with multiple methods** - PCA, MLE, distances should agree

## Valid Results:

Only **final_results/single_task_100models/** has adequate sampling for that specific analysis.

## Next Steps:

See `/experiments/current/` for properly designed experiments with:
- Adequate sampling (100+ models per condition)
- Saturation testing (varying sample sizes)
- Memory-efficient incremental processing
